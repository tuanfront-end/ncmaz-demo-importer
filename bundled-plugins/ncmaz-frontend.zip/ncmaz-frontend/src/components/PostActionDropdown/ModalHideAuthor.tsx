import React from "react";

const ModalHideAuthor = () => {
  return <div>fsfe</div>;
};

export default ModalHideAuthor;
