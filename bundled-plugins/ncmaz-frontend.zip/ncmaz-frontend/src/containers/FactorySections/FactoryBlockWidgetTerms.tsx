import React, { FC, useRef } from "react";
import ReactDOM from "react-dom";
import { GutenbergApiAttr_BlockWidgetTerms } from "data/gutenbergAttrType";
import WidgetCategories from "components/WidgetCategories/WidgetCategories";
import DataStatementBlockV2 from "components/DataStatementBlock/DataStatementBlockV2";
import useGqlQuerySection from "hooks/useGqlQuerySection";
import useGutenbergSectionWithGQLGetTerms from "hooks/useGutenbergSectionWithGQLGetTerms";

export interface FactoryBlockWidgetTermsProps {
  className?: string;
  domNode: Element;
  apiSettings: GutenbergApiAttr_BlockWidgetTerms;
  sectionIndex: number;
}

const FactoryBlockWidgetTerms: FC<FactoryBlockWidgetTermsProps> = ({
  className = "",
  domNode,
  apiSettings,
  sectionIndex,
}) => {
  const { graphQLvariables, graphQLData, settings } = apiSettings;
  const IS_SPECIFIC_DATA = !graphQLvariables && !!graphQLData;

  const { IS_SKELETON, LIST_TERMS, error, funcGqlQueryGetTerms } =
    useGutenbergSectionWithGQLGetTerms({ graphQLvariables, graphQLData });

  //
  let ref: React.RefObject<HTMLDivElement> | null = null;
  if (IS_SPECIFIC_DATA) {
    ref = useRef<HTMLDivElement>(null);
  } else {
    ref = useGqlQuerySection(funcGqlQueryGetTerms, sectionIndex).ref;
  }

  const renderContent = () => {
    return (
      <div ref={ref}>
        <WidgetCategories
          categories={LIST_TERMS}
          heading={settings.heading}
          termCardName={settings.termCardName}
          isLoading={IS_SKELETON}
        />

        <DataStatementBlockV2
          className="my-5"
          data={LIST_TERMS}
          error={error}
          isSkeleton={IS_SKELETON}
        />
      </div>
    );
  };

  return ReactDOM.createPortal(renderContent(), domNode);
};

export default FactoryBlockWidgetTerms;
