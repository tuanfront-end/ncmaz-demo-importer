<?php
class TextFieldTest extends \Codeception\TestCase\WPTestCase {

	public function setUp(): void {

	}

	public function tearDown(): void {

	}

	public function testTextFieldOnPost() {



	}

}
